﻿namespace Dsw2025Tpi.Application.Exceptions;

    public class NoContentException : Exception
    {
        public NoContentException(string message) : base(message)
        {
        }
        
    }
