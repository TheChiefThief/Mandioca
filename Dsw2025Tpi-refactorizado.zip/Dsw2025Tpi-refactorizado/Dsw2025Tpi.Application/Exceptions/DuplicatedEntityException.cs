﻿namespace Dsw2025Tpi.Application.Exceptions;

public class DuplicatedEntityException: ApplicationException
{
    public DuplicatedEntityException(string message): base(message)
    {
        
    }
}
