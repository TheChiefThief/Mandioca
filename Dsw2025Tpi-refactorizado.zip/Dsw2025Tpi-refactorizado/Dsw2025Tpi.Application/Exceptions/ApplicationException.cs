﻿namespace Dsw2025Tpi.Application.Exceptions;

public class ApplicationException : Exception
{
    public ApplicationException(string message): base(message)
    {
        
    }
}
